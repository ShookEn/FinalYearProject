<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class myCart extends Model
{
    


    use HasFactory;
    protected $fillable=['productId','quantity','userID','dateAdd','orderID'];

    public function Hotel (){
        return $this->hasMany('App\Models\Hotel');
    }
    public function Flight (){
        return $this->hasMany('App\Models\Flight');
    }
    public function Cameron(){
        return $this->hasMany('App\Models\Cameron');
    }
    public function Genting(){
        return $this->hasMany('App\Models\Genting');
    }
    public function Johor(){
        return $this->hasMany('App\Models\Johor');
    }
    public function Penang(){
        return $this->hasMany('App\Models\Penang');
    }
    public function Kuala(){
        return $this->hasMany('App\Models\Kuala');
    }

    public function User(){
        return $this->belongsTo('App\Models\user');
    }
}

